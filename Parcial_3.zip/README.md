# IngWebParcial3

Repositorio para el examen de enero de ingenieria web

backend en Railway y frontend en Vercel